package model.compare;

public class NotComparedLine extends Line{
	
	public NotComparedLine(String str){
		this.line = str;
	}
	
}
