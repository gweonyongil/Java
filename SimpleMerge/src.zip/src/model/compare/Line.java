package model.compare;

public abstract class Line {
	public String line;
}
