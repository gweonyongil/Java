package view;

public class SMLauncher {
	public static void main(String args[]){
		MainFrame frame = MainFrame.getInstance();
		frame.initial();
	}
}
