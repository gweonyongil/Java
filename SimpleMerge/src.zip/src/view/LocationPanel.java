package view;

import java.awt.Button;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class LocationPanel extends JPanel{
	public LocationPanel()
	{
		super();
		add(new JLabel("Location Panel"));
	}
}
